# page 111

from setuptools import setup
setup(name = 'acme.sql', version = '0.1.1',
      install_requires=['pysqlite', 'SQLAlchemy'])
