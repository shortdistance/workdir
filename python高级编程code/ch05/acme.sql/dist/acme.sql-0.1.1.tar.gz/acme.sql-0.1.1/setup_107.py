# page 107

from setuptools import setup
setup(name = 'acme.sql', version = '0.1.1')
