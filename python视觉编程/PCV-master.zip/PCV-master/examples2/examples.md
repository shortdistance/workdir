## Exemples for the upcoming edition of PCV

This folder contains work in progress and files intended for the second edition of "Programming Computer Vision with Python".

More details on the book can be found at [programmingcomputervision.com](http://programmingcomputervision.com/)