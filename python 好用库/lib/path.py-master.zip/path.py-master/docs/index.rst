.. path.py documentation master file, created by
   sphinx-quickstart on Tue Apr  9 10:25:52 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to path.py's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   api
   history


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

